package com.example.projekt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private TextView questionText, scoreText;
    private Button startButton, resetButton, answerA, answerB, answerC;

    private ArrayList<Question> allQuestions = new ArrayList<>();
    private ArrayList<Question> quizQuestions = new ArrayList<>();

    private int score = 0;
    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.startButton);
        resetButton = findViewById(R.id.resetButton);
        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);
        answerA = findViewById(R.id.answerA);
        answerB = findViewById(R.id.answerB);
        answerC = findViewById(R.id.answerC);

        loadQuestions();

        startButton.setOnClickListener(v -> startQuiz());

        resetButton.setOnClickListener(v -> resetQuiz());

        View.OnClickListener listener = v -> {
            Button b = (Button) v;
            checkAnswer(b.getText().toString().substring(3));
        };

        answerA.setOnClickListener(listener);
        answerB.setOnClickListener(listener);
        answerC.setOnClickListener(listener);
    }

    private void loadQuestions() {
        allQuestions.add(new Question("Stolica Włoch to:", "Rzym", "Paryż", "Madryt", "Rzym"));
        allQuestions.add(new Question("Największy ocean to:", "Spokojny", "Atlantycki", "Indyjski", "Spokojny"));
        allQuestions.add(new Question("Ile to 5 × 3?", "8", "15", "20", "15"));
        allQuestions.add(new Question("Pierwiastek z 81 to:", "9", "8", "7", "9"));
        allQuestions.add(new Question("Który z tych zwierząt lata?", "Lew", "Sokół", "Pingwin", "Sokół"));
        allQuestions.add(new Question("Jaki kolor powstaje z czerwonego i niebieskiego?", "Zielony", "Fioletowy", "Pomarańczowy", "Fioletowy"));
        allQuestions.add(new Question("Stolica Polski to:", "Kraków", "Warszawa", "Gdańsk", "Warszawa"));
    }

    private void startQuiz() {
        score = 0;
        currentIndex = 0;
        scoreText.setText("Wynik: 0");

        Collections.shuffle(allQuestions);
        quizQuestions = new ArrayList<>(allQuestions.subList(0, 5));

        startButton.setVisibility(View.GONE);

        showQuestion();
    }

    private void showQuestion() {
        if (currentIndex >= quizQuestions.size()) {
            Toast.makeText(this,
                    "Koniec quizu! Twój wynik: " + score + " / 5",
                    Toast.LENGTH_LONG).show();

            startButton.setVisibility(View.VISIBLE);

            questionText.setVisibility(View.GONE);
            answerA.setVisibility(View.GONE);
            answerB.setVisibility(View.GONE);
            answerC.setVisibility(View.GONE);
            return;
        }

        Question q = quizQuestions.get(currentIndex);

        questionText.setText(q.text);
        questionText.setVisibility(View.VISIBLE);

        answerA.setText("A: " + q.a);
        answerB.setText("B: " + q.b);
        answerC.setText("C: " + q.c);

        answerA.setVisibility(View.VISIBLE);
        answerB.setVisibility(View.VISIBLE);
        answerC.setVisibility(View.VISIBLE);
    }

    private void checkAnswer(String chosen) {
        Question q = quizQuestions.get(currentIndex);

        if (chosen.equals(q.correct)) {
            score++;
            scoreText.setText("Wynik: " + score);
        }

        currentIndex++;
        showQuestion();
    }

    private void resetQuiz() {
        score = 0;
        currentIndex = 0;

        scoreText.setText("Wynik: 0");

        startButton.setVisibility(View.VISIBLE);

        questionText.setVisibility(View.GONE);
        answerA.setVisibility(View.GONE);
        answerB.setVisibility(View.GONE);
        answerC.setVisibility(View.GONE);
    }
}
